﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClarionApp {
    public static class GlobalVars {

        // Variable to configure whether we are running in competition mode
        // with other cognitive architectures.
        public const Boolean competitionMode = true;
    }
}
