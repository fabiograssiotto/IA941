/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package SoarBridge;

/**
 *
 * @author Fabio
 */
public class CommandDeliver
{
    
    private String leafletId = null;

    public CommandDeliver()
    {

    }

    /**
     * @return the thingName
     */
    public String getLeafletId()
    {
        return leafletId;
    }

    /**
     * @param thingName the thingName to set
     */
    public void setLeafletId(String leafletId)
    {
        this.leafletId = leafletId;
    }

}
