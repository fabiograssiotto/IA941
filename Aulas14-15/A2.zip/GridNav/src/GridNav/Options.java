/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package GridNav;

/**
 *
 * @author Elias Nygren
 */
public enum Options {
    ASTAR, DIJKSTRA, JPS, NO_HEURISTIC, MANHATTAN_HEURISTIC, DIAGONAL_HEURISTIC, EUCLIDEAN_HEURISTIC, DIAGONAL_EQUAL_COST_HEURISTIC
}
