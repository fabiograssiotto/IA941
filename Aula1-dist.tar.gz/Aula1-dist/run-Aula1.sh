java -jar ws3d/WorldServer3D.jar
java -jar ManualController/ManualController.jar 
