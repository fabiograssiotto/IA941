#!/bin/bash
# Script to launch WordServer3d
java -jar ws3d/WorldServer3D.jar &
sleep 5
# Script to launch DemoLIDA
java -jar DemoLIDA/DemoLIDA.jar &
