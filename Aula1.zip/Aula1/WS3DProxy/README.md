# WS3DProxy
Proxy for accessing the ws3d Virtual Environment directly from Java, without requiring socket communication details. 
